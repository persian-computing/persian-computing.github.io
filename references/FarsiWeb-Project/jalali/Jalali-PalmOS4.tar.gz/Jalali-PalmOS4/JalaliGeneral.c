/* Jalali - Jalali to Gregorian and reverse date converter
 * Copyright (C) 2002 Behdad Esfahbod.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public  
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,  
 * but WITHOUT ANY WARRANTY; without even the implied warranty of   
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License  
 * along with this library, in a file named COPYING; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA
 * 
 * For licensing issues, contact <fwpg@sharif.edu>.
 */

#include "Jalali.h"
#include "unix_stdlib.h"

static void
AlertError (char *theMessage)
{
  FrmCustomAlert (TheError, theMessage, NULL, NULL);
}

void
setGregorian (Int16 gd, Int16 gm, Int16 gy)
{
  FormPtr theForm;
  char ResD[3], ResM[3], ResY[5];
  theForm = FrmGetActiveForm ();

  StrIToA (ResY, gy);
  StrIToA (ResM, gm);
  StrIToA (ResD, gd);
  if (ResD[1] == 0)
    {
      ResD[2] = 0;
      ResD[1] = ResD[0];
      ResD[0] = '0';
    }

  // write the result values into the appropriate fields
  FldInsert (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGD)),
	     ResD, StrLen (ResD));
  FldInsert (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGM)),
	     ResM, StrLen (ResM));
  FldInsert (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGY)),
	     ResY, StrLen (ResY));
}

void
setJalali (Int16 jd, Int16 jm, Int16 jy)
{
  FormPtr theForm;
  char ResD[3], ResM[3], ResY[5];
  theForm = FrmGetActiveForm ();

  StrIToA (ResY, jy);
  StrIToA (ResM, jm);
  StrIToA (ResD, jd);
  if (ResD[1] == 0)
    {
      ResD[2] = 0;
      ResD[1] = ResD[0];
      ResD[0] = '0';
    }

  // write the result values into the appropriate fields
  FldInsert (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldJD)),
	     ResD, StrLen (ResD));
  FldInsert (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldJM)),
	     ResM, StrLen (ResM));
  FldInsert (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldJY)),
	     ResY, StrLen (ResY));
}

int
getGregorian (Int16 * pd, Int16 * pm, Int16 * py, int quite)
{
  char *FldD;
  char *FldM;
  char *FldY;
  Int16 flag = 0, gd, gm, gy;
  FormPtr theForm;
  theForm = FrmGetActiveForm ();

  // get the input
  FldD =
    FldGetTextPtr (FrmGetObjectPtr
		   (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGD)));
  FldM =
    FldGetTextPtr (FrmGetObjectPtr
		   (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGM)));
  FldY =
    FldGetTextPtr (FrmGetObjectPtr
		   (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGY)));

  // check if input is correct
  if ((FldY == NULL) || (gy = atoi (FldY), gy <= 1600 || gy > 9999))
    {
      if (!quite)
	AlertError ("Invalid year!");
      flag = 1;
    }
  else if ((FldM == NULL) || (gm = atoi (FldM), gm < 1 || gm > 12))
    {
      if (!quite)
	AlertError ("Invalid month!");
      flag = 1;
    }
  else if ((FldD == NULL) || (gd = atoi (FldD), gd < 1
			      || gd >
			      g_days_in_month[gm - 1] +
			      gregorian_is_leap (gy) ? g_leap_month[gm -
								    1] : 0))
    {
      if (!quite)
	AlertError ("Invalid day!");
      flag = 1;
    }
  else
    {
      *pd = gd;
      *pm = gm;
      *py = gy;
    }
  return !flag;
}


int
getJalali (Int16 * pd, Int16 * pm, Int16 * py, int quite)
{
  char *FldD;
  char *FldM;
  char *FldY;
  Int16 flag = 0, jd, jm, jy;
  FormPtr theForm;
  theForm = FrmGetActiveForm ();

  // get the input
  FldD =
    FldGetTextPtr (FrmGetObjectPtr
		   (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldJD)));
  FldM =
    FldGetTextPtr (FrmGetObjectPtr
		   (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldJM)));
  FldY =
    FldGetTextPtr (FrmGetObjectPtr
		   (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldJY)));

  // check if input is correct
  if ((FldY == NULL) || (jy = atoi (FldY), jy > 9377 || jy <= 979))
    {
      if (!quite)
	AlertError ("Invalid year!");
      flag = 1;
    }
  else if ((FldM == NULL) || (jm = atoi (FldM), jm < 1 || jm > 12))
    {
      if (!quite)
	AlertError ("Invalid month!");
      flag = 1;
    }
  else if ((FldD == NULL) || (jd = atoi (FldD), jd < 1
			      || jd >
			      j_days_in_month[jm - 1] +
			      jalali_is_leap (jy) ? j_leap_month[jm - 1] : 0))
    {
      if (!quite)
	AlertError ("Invalid day!");
      flag = 1;
    }
  else
    {
      *pd = jd;
      *pm = jm;
      *py = jy;
    }
  return !flag;
}

void
clearGregorian (void)
{
  FormPtr theForm;
  theForm = FrmGetActiveForm ();

  // delete old entries
  FldDelete (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGD)), 0, 2);
  FldDelete (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGM)), 0, 2);
  FldDelete (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGY)), 0, 4);
}

void
clearJalali (void)
{
  FormPtr theForm;
  theForm = FrmGetActiveForm ();

  // delete old entries
  FldDelete (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldJD)), 0, 2);
  FldDelete (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldJM)), 0, 2);
  FldDelete (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldJY)), 0, 4);
}

static int
convertFromGregorian (int quite)
{
  Int16 flag = 0, gd, gm, gy, jd, jm, jy;
  FormPtr theForm;
  theForm = FrmGetActiveForm ();

  clearJalali ();

  if (getGregorian (&gd, &gm, &gy, quite))
    {
      gregorian_to_jalali (&jy, &jm, &jd, gy, gm, gd);
      setJalali (jd, jm, jy);
    }
  return !flag;
}

static int
convertFromJalali (int quite)
{
  Int16 flag = 0, jd, jm, jy, gd, gm, gy;
  FormPtr theForm;
  theForm = FrmGetActiveForm ();

  clearGregorian ();

  if (getJalali (&jd, &jm, &jy, quite))
    {
      jalali_to_gregorian (&gy, &gm, &gd, jy, jm, jd);
      setGregorian (gd, gm, gy);
    }
  return !flag;
}

void
EncodeGregorian (char *buf)
{
  char *s;
  FormPtr theForm = FrmGetActiveForm ();

  s = FldGetTextPtr (FrmGetObjectPtr
		     (theForm,
		      FrmGetObjectIndex (theForm, JalaliFormFieldGD)));
  buf[0] = s[0];
  buf[1] = s[1];
  s = FldGetTextPtr (FrmGetObjectPtr
		     (theForm,
		      FrmGetObjectIndex (theForm, JalaliFormFieldGM)));
  buf[2] = s[0];
  buf[3] = s[1];
  s = FldGetTextPtr (FrmGetObjectPtr
		     (theForm,
		      FrmGetObjectIndex (theForm, JalaliFormFieldGY)));
  buf[4] = s[0];
  buf[5] = s[1];
  buf[6] = s[2];
  buf[7] = s[3];

  return;
}

void
DecodeGregorian (char *buf)
{
  char s[5];
  FormPtr theForm = FrmGetActiveForm ();

  s[0] = buf[0];
  s[1] = buf[1];
  s[2] = 0;
  FldInsert (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGD)),
	     s, StrLen (s));
  s[0] = buf[2];
  s[1] = buf[3];
  s[2] = 0;
  if (s[1] == ' ')
    s[1] = 0;
  FldInsert (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGM)),
	     s, StrLen (s));
  s[0] = buf[4];
  s[1] = buf[5];
  s[2] = buf[6];
  s[3] = buf[7];
  s[4] = 0;
  FldInsert (FrmGetObjectPtr
	     (theForm, FrmGetObjectIndex (theForm, JalaliFormFieldGY)),
	     s, StrLen (s));

  return;
}

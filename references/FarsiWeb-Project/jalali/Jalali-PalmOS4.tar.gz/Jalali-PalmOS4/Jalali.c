/* Jalali - Jalali to Gregorian and reverse date converter
 * Copyright (C) 2002 Behdad Esfahbod.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public  
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,  
 * but WITHOUT ANY WARRANTY; without even the implied warranty of   
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License  
 * along with this library, in a file named COPYING; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA
 * 
 * For licensing issues, contact <fwpg@sharif.edu>.
 */

#include "Jalali.h"
#include "JalaliConvert.c"
#include "JalaliGeneral.c"
#include "EventHandlers.c"

static void
EventLoop (void)
{
  EventType event;
  UInt16 error;

  do
    {
      EvtGetEvent (&event, evtWaitForever);
      if (!SysHandleEvent (&event))
	{
	  if (!MenuHandleEvent (0, &event, &error))
	    {
	      if (!ApplicationHandleEvent (&event))
		{
		  FrmDispatchEvent (&event);
		}
	    }
	}
    }
  while (event.eType != appStopEvent && !done);
}

static Err
OpenDatabase (void)
{
  Err err = 0;
  UInt index = 0;
  VoidHand RecHandle;
  MemPtr RecPointer;

  myDB = DmOpenDatabaseByTypeCreator (myDBType, myAppID, dmModeReadWrite);
  if (!myDB)
    {
      if ((err =
	   DmCreateDatabase (0, myDBName, myAppID, myDBType, false)) != 0)
	return err;
      myDB = DmOpenDatabaseByTypeCreator (myDBType, myAppID, dmModeReadWrite);
      RecHandle = DmNewRecord (myDB, &index, 8);
      RecPointer = MemHandleLock (RecHandle);
      DmWrite (RecPointer, 0, "279 1982", 8);
      MemPtrUnlock (RecPointer);
      DmReleaseRecord (myDB, index, true);
    }
  return 0;
}

static Err
StartApplication (void)
{
  Err err = 0;
  err = OpenDatabase ();
  if (err)
    return err;

  FrmGotoForm (JalaliForm);
  return 0;
}

static Err
StopApplication (void)
{
  VoidHand myRecord;
  FormPtr theForm;
  char theRecord[8];
  MemPtr RecPointer;
  UInt index = 0;
  theForm = FrmGetActiveForm ();
  EncodeGregorian (theRecord);
  if (theRecord != NULL)
    {
      DmRemoveRecord (myDB, index);
      myRecord = DmNewRecord (myDB, &index, 1);
      myRecord = DmResizeRecord (myDB, index, 8);
      RecPointer = MemHandleLock (myRecord);
      DmWrite (RecPointer, 0, theRecord, 8);
      MemPtrUnlock (RecPointer);
      DmReleaseRecord (myDB, index, true);
    }
  DmCloseDatabase (myDB);
  return 0;
}

UInt32
PilotMain (UInt16 launchCode, MemPtr cmdPBP, UInt16 launchFlags)
{
  Err err = 0;

  if (launchCode == sysAppLaunchCmdNormalLaunch)
    {
      if ((err = StartApplication ()) == 0)
	{
	  EventLoop ();
	  StopApplication ();
	}
    }
  return err;
}

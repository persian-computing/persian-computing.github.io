#ifndef __COLORS_H
#define __COLORS_H

#include <PalmCompatibility.h>
#include <PalmOS.h>
#include <stdio.h>
#include <stdlib.h>
#include <unix_stdlib.h>
#include "JalaliRsc.h"

#ifdef __GNUC__
#include "Callbacks.h"
#endif

#define myAppID                 'CLRS'
#define myDBType                'Data'

DmOpenRef myDB;
char myDBName[] = "JalaliDB";


static void AlertError (char *);
static Boolean JalaliFormHandleEvent (EventPtr);
static Boolean ApplicationHandleEvent (EventPtr);
static void EventLoop (void);
static Err OpenDatabase (void);
static Err StartApplication (void);
static Err StopApplication (void);
DWord PilotMain (Word launchCode, Ptr cmdPBP, Word launchFlags);

#endif

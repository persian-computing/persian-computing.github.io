   // JalaliRsc.h
   // defines constants for all the applications resources
   //
   // App Name: "Jalali"
   //
   // App Version: "0.1"

   // Main Form
#define JalaliForm                           1000

   // main menu
#define JalaliMainMenuBar                    1000
#define Cut                                  1001
#define Copy                                 1002
#define Paste                                1003
#define Info                                 1004

   // fields and buttons
#define JalaliFormFieldJD                    1010
#define JalaliFormFieldJM                    1011
#define JalaliFormFieldJY                    1012
#define JalaliFormButtonFromJalali           1013
#define JalaliFormButtonFromGregorian        1014
#define JalaliFormFieldGD                    1015
#define JalaliFormFieldGM                    1016
#define JalaliFormFieldGY                    1017
#define JalaliFormButtonOK                   1018
#define JalaliFormButtonGoToG                1019

   // Alerts
#define AboutAlert                           2000
#define TheError                             3000

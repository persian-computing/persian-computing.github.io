/* Jalali - Jalali to Gregorian and reverse date converter
 * Copyright (C) 2002 Behdad Esfahbod.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public  
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,  
 * but WITHOUT ANY WARRANTY; without even the implied warranty of   
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License  
 * along with this library, in a file named COPYING; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA
 * 
 * For licensing issues, contact <fwpg@sharif.edu>.
 */

#include "Jalali.h"

int done = 0;

static Boolean
JalaliFormHandleEvent (EventPtr event)
{
  Boolean handled = false;
  int objID;
  FormPtr theForm;
  VoidHand myRecord;
  UInt index;
  char *theRecord;

#ifdef __GNUC__
  CALLBACK_PROLOGUE
#endif
    index = 0;
  theForm = FrmGetActiveForm ();
  switch (event->eType)
    {
    case frmOpenEvent:
      // get the record
      myRecord = DmGetRecord (myDB, index);
      theRecord = MemHandleLock (myRecord);
      MemHandleUnlock (myRecord);
      DmReleaseRecord (myDB, index, true);
      FrmDrawForm (theForm);
      if ((theRecord != NULL))
	{
	  // we have a valid record, display it
	  DecodeGregorian (theRecord);
	  // and show the jalali - this way we don't need to store those!
	  if (!convertFromGregorian (1))
	    {
	      // TODO set to current date
	      convertFromGregorian (1);
	    };
	}
      handled = true;
      break;
    case ctlSelectEvent:
      objID = event->data.ctlSelect.controlID;
      if (objID == JalaliFormButtonFromJalali)
	{
	  convertFromJalali (0);
	}
      else if (objID == JalaliFormButtonFromGregorian)
	{
	  convertFromGregorian (0);
	}
      else if (objID == JalaliFormButtonGoToG)
	{
	  Int16 m, d, y;
	  if (getGregorian (&d, &m, &y, 0))
	    {
	      if (SelectDay (selectDayByDay, &m, &d, &y, "Gregorian Date"))
		{
		  clearGregorian ();
		  setGregorian (d, m, y);
		  convertFromGregorian (1);
		}
	    }
	}
      else
	{
	  done = 1;
	}
      handled = true;
      break;
    case menuEvent:
      if (event->data.menu.itemID == Cut)
	{
	  // Cut
	  objID = FrmGetFocus (theForm);
	  FldCut (FrmGetObjectPtr (theForm, objID));
	}
      else if (event->data.menu.itemID == Copy)
	{
	  // Copy
	  objID = FrmGetFocus (theForm);
	  FldCopy (FrmGetObjectPtr (theForm, objID));
	  break;
	}
      else if (event->data.menu.itemID == Paste)
	{
	  // Paste
	  objID = FrmGetFocus (theForm);
	  FldPaste (FrmGetObjectPtr (theForm, objID));
	  break;
	}
      else if (event->data.menu.itemID == Info)
	// display info
	FrmAlert (AboutAlert);
      handled = true;
      break;
    default:
    }

#ifdef __GNUC__
  CALLBACK_EPILOGUE
#endif
    return handled;
}

static Boolean
ApplicationHandleEvent (EventPtr event)
{
  FormPtr frm;
  Int formId;
  Boolean handled = false;

  if (event->eType == frmLoadEvent)
    {
      // Load the form resource specified in the event, then activate it
      formId = event->data.frmLoad.formID;
      frm = FrmInitForm (formId);
      FrmSetActiveForm (frm);

      // Set the event Handler for the form. The handler of the currently active form
      // is called by FrmDispatchEvent each time it is called
      switch (formId)
	{
	case JalaliForm:
	  FrmSetEventHandler (frm, JalaliFormHandleEvent);
	  break;
	}
      handled = true;
    }
  return handled;
}

// This file is part of:
//    Jalali, a Gregorian to Jalali and reverse date convertor
// Copyright (C) 2001 Roozbeh Pournader
// Copyright (C) 2001 Mohammad Toossi
// Copyright (C) 2001 Mehrdad Sabetzadeh
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
// For licensing issues, contact The FarsiWeb Project Group,
// Computing Center, Sharif University of Technology,
// Tehran, Iran, or <mailto:FWPG@sharif.ac.ir>

// jalaliDlg.cpp : implementation file
//

#include <winbase.h>

#include "stdafx.h"
#include "jalali.h"
#include "jalaliDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJalaliDlg dialog

CJalaliDlg::CJalaliDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CJalaliDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CJalaliDlg)
	m_JD = -1;
	m_JM = -1;
	m_JY = 0;
	m_GD = -1;
	m_GM = -1;
	m_GY = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CJalaliDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CJalaliDlg)
	DDX_CBIndex(pDX, IDC_JD, m_JD);
	DDX_CBIndex(pDX, IDC_JM, m_JM);
	DDX_Text(pDX, IDC_JY, m_JY);
	DDX_CBIndex(pDX, IDC_GD, m_GD);
	DDX_CBIndex(pDX, IDC_GM, m_GM);
	DDX_Text(pDX, IDC_GY, m_GY);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CJalaliDlg, CDialog)
	//{{AFX_MSG_MAP(CJalaliDlg)
	ON_BN_CLICKED(IDC_J2G, OnJ2G)
	ON_BN_CLICKED(IDC_G2J, OnG2J)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJalaliDlg message handlers

BOOL CJalaliDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CenterWindow(GetDesktopWindow());	// center to the hpc screen

	GetLocalTime(&systime);
	m_GD = systime.wDay-1;
	m_GM = systime.wMonth-1;
	m_GY = systime.wYear;
	gregorian_to_jalali(&m_JY, &m_JM, &m_JD, m_GY, m_GM+1, m_GD+1);
	--m_JD;
	--m_JM;
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CJalaliDlg::OnJ2G() 
{
	UpdateData();
	jalali_to_gregorian(&m_GY, &m_GM, &m_GD, m_JY, m_JM+1, m_JD+1);
	--m_GD;
	--m_GM;
	UpdateData(FALSE);
}

void CJalaliDlg::OnG2J() 
{
	UpdateData();
	gregorian_to_jalali(&m_JY, &m_JM, &m_JD, m_GY, m_GM+1, m_GD+1);
	--m_JD;
	--m_JM;
	UpdateData(FALSE);
}


int g_days_in_month[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
int j_days_in_month[12] = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};

void gregorian_to_jalali(
	int *j_y,
	int *j_m,
	int *j_d,
	const int g_y,
	const int g_m,
	const int g_d)
{
   int gy, gm, gd;
   int jy, jm, jd;
   long g_day_no, j_day_no;
   int j_np;
 
   int i;
   gy = g_y-1600;
   gm = g_m-1;
   gd = g_d-1;
 
   g_day_no = 365*gy+(gy+3)/4-(gy+99)/100+(gy+399)/400;
   for (i=0;i<gm;++i)
      g_day_no += g_days_in_month[i];
   if (gm>1 && ((gy%4==0 && gy%100!=0) || (gy%400==0)))
      /* leap and after Feb */
      ++g_day_no;
   g_day_no += gd;
 
   j_day_no = g_day_no-79;
 
   j_np = j_day_no / 12053;
   j_day_no %= 12053;
 
   jy = 979+33*j_np+4*(j_day_no/1461);
   j_day_no %= 1461;
 
   if (j_day_no >= 366) {
      jy += (j_day_no-1)/365;
      j_day_no = (j_day_no-1)%365;
   }
 
   for (i = 0; j_day_no >= j_days_in_month[i]; ++i) {
      j_day_no -= j_days_in_month[i];
   }
   jm = i+1;
   jd = j_day_no+1;
   *j_y = jy;
   *j_m = jm;
   *j_d = jd;
}

#define div(a, b) ((a)/(b))

void jalali_to_gregorian(
	int *g_y,
	int *g_m,
	int *g_d,
	const int j_y,
	const int j_m,
	const int j_d)
{
   int gy, gm, gd;
   int jy, jm, jd;
   long g_day_no, j_day_no;
   int leap;

   int i;

   jy = j_y-979;
   jm = j_m-1;
   jd = j_d-1;

   j_day_no = 365*jy + (jy/33)*8 + (jy%33+3)/4;
   for (i=0; i < jm; ++i)
      j_day_no += j_days_in_month[i];

   j_day_no += jd;

   g_day_no = j_day_no+79;

   gy = 1600 + 400*div(g_day_no, 146097); /* 146097 = 365*400 + 400/4 - 400/100 + 400/400 */
   g_day_no = g_day_no % 146097;

   leap = TRUE;
   if (g_day_no >= 36525) /* 36525 = 365*100 + 100/4 */
   {
      g_day_no--;
      gy += 100*div(g_day_no,  36524); /* 36524 = 365*100 + 100/4 - 100/100 */
      g_day_no = g_day_no % 36524;
      
      if (g_day_no >= 365)
         g_day_no++;
      else
         leap = FALSE;
   }

   gy += 4*div(g_day_no, 1461); /* 1461 = 365*4 + 4/4 */
   g_day_no %= 1461;

   if (g_day_no >= 366) {
      leap = FALSE;

      g_day_no--;
      gy += div(g_day_no, 365);
      g_day_no = g_day_no % 365;
   }

   for (i = 0; g_day_no >= g_days_in_month[i] + (i == 1 && leap); i++)
      g_day_no -= g_days_in_month[i] + (i == 1 && leap);
   gm = i+1;
   gd = g_day_no+1;

   *g_y = gy;
   *g_m = gm;
   *g_d = gd;
}

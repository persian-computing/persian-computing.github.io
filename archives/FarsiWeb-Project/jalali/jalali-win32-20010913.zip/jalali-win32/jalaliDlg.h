// This file is part of:
//    Jalali, a Gregorian to Jalali and reverse date convertor
// Copyright (C) 2001 Roozbeh Pournader
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
// For licensing issues, contact The FarsiWeb Project Group,
// Computing Center, Sharif University of Technology,
// Tehran, Iran, or <mailto:FWPG@sharif.ac.ir>

// jalaliDlg.h : header file
//

#if !defined(AFX_JALALIDLG_H__931367B4_096B_46C5_B5F0_5EA88DC2C743__INCLUDED_)
#define AFX_JALALIDLG_H__931367B4_096B_46C5_B5F0_5EA88DC2C743__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


void gregorian_to_jalali(
	int *j_y,
	int *j_m,
	int *j_d,
	const int g_y,
	const int g_m,
	const int g_d);

void jalali_to_gregorian(
	int *g_y,
	int *g_m,
	int *g_d,
	const int j_y,
	const int j_m,
	const int j_d);


/////////////////////////////////////////////////////////////////////////////
// CJalaliDlg dialog

class CJalaliDlg : public CDialog
{
// Construction
public:
	SYSTEMTIME systime;
	CJalaliDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CJalaliDlg)
	enum { IDD = IDD_JALALI_DIALOG };
	int		m_JD;
	int		m_JM;
	int		m_JY;
	int		m_GD;
	int		m_GM;
	int		m_GY;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJalaliDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CJalaliDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnJ2G();
	afx_msg void OnG2J();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_JALALIDLG_H__931367B4_096B_46C5_B5F0_5EA88DC2C743__INCLUDED_)

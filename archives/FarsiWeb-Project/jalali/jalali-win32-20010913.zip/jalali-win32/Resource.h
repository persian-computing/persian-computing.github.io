//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by jalali.rc
//
#define IDD_JALALI_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDB_J2G                         130
#define IDB_G2J                         131
#define IDI_J2G                         134
#define IDI_G2J                         136
#define IDC_JD                          1003
#define IDC_JM                          1004
#define IDC_GD                          1005
#define IDC_JY                          1006
#define IDC_GM                          1007
#define IDC_GY                          1008
#define IDC_J2G                         1012
#define IDC_G2J                         1013
#define IDC_COPYRIGHT                   1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
